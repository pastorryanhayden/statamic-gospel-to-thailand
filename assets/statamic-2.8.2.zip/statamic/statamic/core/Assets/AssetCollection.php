<?php

namespace Statamic\Assets;

use Statamic\Data\DataCollection;

class AssetCollection extends DataCollection
{
}
