<?php

namespace Statamic\Data\Entries;

use Statamic\Data\Content\ContentCollection;

class EntryCollection extends ContentCollection
{
    //
}
