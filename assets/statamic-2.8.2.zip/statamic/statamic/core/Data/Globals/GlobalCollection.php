<?php

namespace Statamic\Data\Globals;

use Statamic\Data\Content\ContentCollection;

class GlobalCollection extends ContentCollection
{
}
