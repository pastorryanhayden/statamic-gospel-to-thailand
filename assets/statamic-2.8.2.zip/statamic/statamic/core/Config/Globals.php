<?php

namespace Statamic\Config;

use Statamic\API\File;
use Statamic\API\YAML;

class Globals extends Config
{
    /**
     * Save the config
     *
     * @return void
     */
    public function save()
    {
        // @todo
    }
}
