<?php

namespace Statamic\Contracts\Data\Content;

interface UrlBuilder
{
}
