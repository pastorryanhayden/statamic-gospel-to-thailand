<?php

namespace Statamic\Addons\Radio;

use Statamic\Extend\Fieldtype;

class RadioFieldtype extends Fieldtype
{
}
