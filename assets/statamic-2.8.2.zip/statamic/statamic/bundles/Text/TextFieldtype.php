<?php

namespace Statamic\Addons\Text;

use Statamic\Extend\Fieldtype;

class TextFieldtype extends Fieldtype
{
}