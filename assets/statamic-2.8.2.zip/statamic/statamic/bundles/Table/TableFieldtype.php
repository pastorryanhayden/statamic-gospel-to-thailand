<?php

namespace Statamic\Addons\Table;

use Statamic\API\Helper;
use Statamic\Extend\Fieldtype;

class TableFieldtype extends Fieldtype
{
}
