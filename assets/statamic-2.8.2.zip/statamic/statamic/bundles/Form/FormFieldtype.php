<?php

namespace Statamic\Addons\Form;

use Statamic\Addons\Relate\RelateFieldtype;

class FormFieldtype extends RelateFieldtype
{
}
