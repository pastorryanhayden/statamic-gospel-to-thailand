<?php

namespace Statamic\Addons\RedactorSettings;

use Statamic\Extend\Fieldtype;

class RedactorSettingsFieldtype extends Fieldtype
{
}
