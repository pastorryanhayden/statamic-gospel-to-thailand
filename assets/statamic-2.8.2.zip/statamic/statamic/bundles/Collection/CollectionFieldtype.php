<?php

namespace Statamic\Addons\Collection;

use Statamic\Addons\Relate\RelateFieldtype;

class CollectionFieldtype extends RelateFieldtype
{

}
