<?php

namespace Statamic\Addons\Collections;

use Statamic\Addons\Relate\RelateFieldtype;

class CollectionsFieldtype extends RelateFieldtype
{

}
