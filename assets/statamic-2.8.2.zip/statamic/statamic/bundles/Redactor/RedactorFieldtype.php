<?php

namespace Statamic\Addons\Redactor;

use Statamic\Extend\Fieldtype;

class RedactorFieldtype extends Fieldtype
{
}
