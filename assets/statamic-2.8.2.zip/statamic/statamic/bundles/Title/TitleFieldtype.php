<?php

namespace Statamic\Addons\Title;

use Statamic\Extend\Fieldtype;

class TitleFieldtype extends Fieldtype
{
    
}
