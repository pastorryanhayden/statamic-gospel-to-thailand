<?php

namespace Statamic\Addons\Theme;

use Statamic\Extend\Fieldtype;

class ThemeFieldtype extends Fieldtype
{
}
